import React, { useState, useEffect,useRef } from 'react';
import './App.css';
import { Card } from 'primereact/card';
import { useFormik } from 'formik';
import { InputText } from "primereact/inputtext";
import { Button } from 'primereact/button';
import { Toast } from 'primereact/toast';
import { classNames } from 'primereact/utils';


function App() {


    // ===========================================================================
    // STATI DEI COMPONENTI ...
    // ===========================================================================


    const [risultato, setRisultato] = useState([{name:'',region:'',population:'',flag:'',currencies:[{name:''}],languages:[{nativeName:''}]}]);
    const [NomeCitta,setNomeCitta] =  useState('napoli');
    const [weather,setWeather] = useState ({icon:'',temperature:''});
    
    
    let header = (
        <img alt="Card" src={risultato[0].flag} />
    );

    const footer = (
        <div className="flex flex-wrap justify-content-end gap-2">

        </div>
    );
  
        const toast = useRef(null);
    
        const show = () => {
            toast.current.show({ severity: 'success', summary: 'Form Submitted', detail: formik.values.value });
        };
    
        const formik = useFormik({
            initialValues: {
                value: ''
            },
            validate: (data) => {
                let errors = {};
    
                if (!data.value) {
                    errors.value = 'Name - Surname is required.';
                }
    
                return errors;
            },
            onSubmit: (data) => {
                data && show(data);
                setNomeCitta(data.value);
                formik.resetForm();
            }
        });
    
        const isFormFieldInvalid = (name) => !!(formik.touched[name] && formik.errors[name]);
    
        const getFormErrorMessage = (name) => {
            return isFormFieldInvalid(name) ? <small className="p-error">{formik.errors[name]}</small> : <small className="p-error">&nbsp;</small>;
        };






    // ===========================================================================
    // USE EFFECT, USE CALLBACK ....
    // ===========================================================================
    

    useEffect(() => {

       
        const options = {
            method: 'GET',
            headers: {
                'X-RapidAPI-Key': '46c7f6e68dmshf80d931ac1f4f30p1c03fcjsn8e0d564752f1',
                'X-RapidAPI-Host': 'forward-reverse-geocoding.p.rapidapi.com'
            }
        };
        
        fetch(`https://forward-reverse-geocoding.p.rapidapi.com/v1/forward?city=${NomeCitta}&accept-language=en&polygon_threshold=0.0`, options)
            .then(response => response.json())
            .then(data => {return geo(data[0].lat,data[0].lon)})
            .catch(err => console.error(err));
       
        
        },[NomeCitta]);

        

function geo(lat,lon){

        const options = {
            method: 'GET',
            headers: {
                'X-RapidAPI-Key': '46c7f6e68dmshf80d931ac1f4f30p1c03fcjsn8e0d564752f1',
                'X-RapidAPI-Host': 'feroeg-reverse-geocoding.p.rapidapi.com'
            }
        };

       

        fetch(`https://feroeg-reverse-geocoding.p.rapidapi.com/address?lat=${lat}&lon=${lon}&lang=en&mode=json`, options)
            .then(response => response.json())
            .then(data => {
               // console.log(`You are in ${data.AdminAreas[2]},${data.AdminAreas[0]}`);
                return fetch(`https://restcountries.com/v2/name/${data.AdminAreas[0]}`);
            })
            .then(response => {
                //console.log(response);
                if (!response.ok) throw new Error("Errore trovato");
                return response.json();
            })
            .then(data => {
                console.log(data);
                setRisultato(data);
            })



            const optionss = {
                method: 'GET',
                headers: {
                    'X-RapidAPI-Key': '46c7f6e68dmshf80d931ac1f4f30p1c03fcjsn8e0d564752f1',
                    'X-RapidAPI-Host': 'ai-weather-by-meteosource.p.rapidapi.com'
                }
            };
            
            fetch(`https://ai-weather-by-meteosource.p.rapidapi.com/current?lat=${lat}&lon=${lon}&timezone=auto&language=en&units=auto`, optionss)
                .then(response => response.json())
                .then(response => setWeather(response.current))
                
                .catch(err => console.error(err));
              
}







    // =========================================================================== 
    // CORPO DELLA PAGINA FINALE
    // ===========================================================================  
    return (
        <center>
            <div className='container'>
               <br></br>
            <div>

                <Card className="card" title={risultato[0].name} subTitle={risultato[0].region} header={header} footer={footer}>
                    <p className="m-0">
                        Popolazione: {Math.trunc((risultato[0].population)/1000000)}M
                    </p>
                    <p className="m-0">
                        Lingua: {risultato[0].languages[0].nativeName}
                    </p>
                    <p className="m-0">
                        Valuta: {risultato[0].currencies[0].name}
                    </p>

                </Card>
            </div>
            
            <div className="card flex justify-content-center">
            <p className="m-0">Inserire Città da Ricercare</p>
            <form onSubmit={formik.handleSubmit} className="flex flex-column gap-2">
                <span className="p-float-label">
                    <Toast ref={toast} />
                    <InputText
                        id="value"
                        name="value"
                        value={formik.values.value}
                     
                        onChange={(e) => {
                            formik.setFieldValue('value', e.target.value);
                       
                        }}
                        className={classNames({ 'p-invalid': isFormFieldInvalid('value') })}
                    />
                </span>
                {getFormErrorMessage('value')}
                <br></br>
                <Button type="submit"  label="Cerca" />
            </form>
        </div>
        <div className='card container2'>
            <h1>WEATHER</h1>
        <h1 className='temperatura'>{weather.temperature}°</h1>
        <img alt='' className='icon' src={'./'+weather.icon+'.png'}/>
      
        </div>
        <br></br>
        </div>
        </center>

    )

                    }

export default App;
